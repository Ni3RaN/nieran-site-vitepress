import{_ as s,c as n,o as a,d as l}from"./app.26036da2.js";const y=JSON.parse('{"title":"Narcissus","description":"","frontmatter":{},"headers":[{"level":2,"title":"项目结构","slug":"项目结构","link":"#项目结构","children":[]},{"level":2,"title":"快速运行","slug":"快速运行","link":"#快速运行","children":[]}],"relativePath":"Narcissus/quick-start.md"}'),p={name:"Narcissus/quick-start.md"},e=l(`<h1 id="narcissus" tabindex="-1">Narcissus <a class="header-anchor" href="#narcissus" aria-hidden="true">#</a></h1><h2 id="项目结构" tabindex="-1">项目结构 <a class="header-anchor" href="#项目结构" aria-hidden="true">#</a></h2><div class="language-"><button title="Copy Code" class="copy"></button><span class="lang"></span><pre class="shiki material-palenight"><code><span class="line"><span style="color:#A6ACCD;">Narcissus</span></span>
<span class="line"><span style="color:#A6ACCD;">├─CMakeLists.txt</span></span>
<span class="line"><span style="color:#A6ACCD;">├─config.json</span></span>
<span class="line"><span style="color:#A6ACCD;">├─start.sh</span></span>
<span class="line"><span style="color:#A6ACCD;">├─src</span></span>
<span class="line"><span style="color:#A6ACCD;">|  ├─config.cpp</span></span>
<span class="line"><span style="color:#A6ACCD;">|  ├─config.h</span></span>
<span class="line"><span style="color:#A6ACCD;">|  ├─main.cpp</span></span>
<span class="line"><span style="color:#A6ACCD;">|  ├─webserver.cpp</span></span>
<span class="line"><span style="color:#A6ACCD;">|  ├─webserver.h</span></span>
<span class="line"><span style="color:#A6ACCD;">|  ├─timer</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |   ├─Utils.cpp</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |   ├─Utils.h</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |   ├─util_timer.h</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |   ├─set</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |   |  ├─set_timer.cpp</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |   |  └set_timer.h</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |   ├─heap</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |   |  ├─heap_timer.cpp</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |   |  └heap_timer.h</span></span>
<span class="line"><span style="color:#A6ACCD;">|  ├─threadpool</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |     └threadpool.h</span></span>
<span class="line"><span style="color:#A6ACCD;">|  ├─mysql</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |   ├─sql_connection_pool.cpp</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |   └sql_connection_pool.h</span></span>
<span class="line"><span style="color:#A6ACCD;">|  ├─log</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |  ├─log.cpp</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |  └log.h</span></span>
<span class="line"><span style="color:#A6ACCD;">|  ├─lock</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |  ├─block_queue.h</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |  └locker.h</span></span>
<span class="line"><span style="color:#A6ACCD;">|  ├─http</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |  ├─http_conn.cpp</span></span>
<span class="line"><span style="color:#A6ACCD;">|  |  └http_conn.h</span></span>
<span class="line"><span style="color:#A6ACCD;"></span></span></code></pre></div><h2 id="快速运行" tabindex="-1">快速运行 <a class="header-anchor" href="#快速运行" aria-hidden="true">#</a></h2>`,4),c=[e];function o(t,r,i,C,A,h){return a(),n("div",null,c)}const d=s(p,[["render",o]]);export{y as __pageData,d as default};
